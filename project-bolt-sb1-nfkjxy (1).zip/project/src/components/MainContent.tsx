import React from 'react';
import { Play, Clock } from 'lucide-react';
import { playlists } from '../data/playlists';
import { usePlayerStore } from '../store/playerStore';

export default function MainContent() {
  const { setCurrentTrack } = usePlayerStore();

  return (
    <div className="p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Good afternoon</h1>
        <div className="grid grid-cols-3 gap-4">
          {playlists.map((playlist) => (
            <div
              key={playlist.id}
              className="flex items-center bg-gray-800/50 rounded-md overflow-hidden hover:bg-gray-800 transition group"
            >
              <img
                src={playlist.cover}
                alt={playlist.title}
                className="w-20 h-20 object-cover"
              />
              <div className="flex-1 p-4">
                <h3 className="font-bold">{playlist.title}</h3>
              </div>
              <button className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 mr-4 hover:scale-105 transition shadow-lg">
                <Play className="ml-1" size={24} />
              </button>
            </div>
          ))}
        </div>
      </header>

      <section>
        <h2 className="text-2xl font-bold mb-6">Made for You</h2>
        <div className="grid grid-cols-5 gap-6">
          {playlists.map((playlist) => (
            <div
              key={playlist.id}
              className="bg-gray-800/50 p-4 rounded-md hover:bg-gray-800 transition group"
            >
              <div className="relative mb-4">
                <img
                  src={playlist.cover}
                  alt={playlist.title}
                  className="w-full aspect-square object-cover rounded-md"
                />
                <button className="absolute bottom-2 right-2 w-10 h-10 bg-green-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition shadow-lg">
                  <Play className="ml-1" size={20} />
                </button>
              </div>
              <h3 className="font-bold mb-1">{playlist.title}</h3>
              <p className="text-sm text-gray-400">{playlist.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="text-2xl font-bold mb-6">Recent Tracks</h2>
        <div className="bg-gray-800/50 rounded-md">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-700 text-gray-400 text-sm">
                <th className="py-3 px-4">#</th>
                <th className="py-3 px-4">Title</th>
                <th className="py-3 px-4">Album</th>
                <th className="py-3 px-4 text-right">
                  <Clock size={16} />
                </th>
              </tr>
            </thead>
            <tbody>
              {playlists.flatMap((playlist) =>
                playlist.tracks.map((track, index) => (
                  <tr
                    key={track.id}
                    className="hover:bg-gray-800 group cursor-pointer"
                    onClick={() => setCurrentTrack(track)}
                  >
                    <td className="py-3 px-4 w-12">{index + 1}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-4">
                        <img
                          src={track.cover}
                          alt={track.title}
                          className="w-10 h-10 rounded"
                        />
                        <div>
                          <div className="font-medium">{track.title}</div>
                          <div className="text-sm text-gray-400">{track.artist}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-400">{track.album}</td>
                    <td className="py-3 px-4 text-gray-400 text-right">{track.duration}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}