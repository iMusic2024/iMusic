import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Repeat, Shuffle } from 'lucide-react';
import { usePlayerStore } from '../store/playerStore';

export default function Player() {
  const { currentTrack, isPlaying, volume, setIsPlaying, setVolume } = usePlayerStore();

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-gray-900 to-black border-t border-gray-800 px-4 py-3">
      <div className="max-w-screen-xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-4 w-1/4">
          <img
            src={currentTrack.cover}
            alt={currentTrack.title}
            className="w-14 h-14 rounded-md"
          />
          <div>
            <h4 className="font-medium text-sm">{currentTrack.title}</h4>
            <p className="text-xs text-gray-400">{currentTrack.artist}</p>
          </div>
        </div>

        <div className="flex flex-col items-center gap-2 w-2/4">
          <div className="flex items-center gap-6">
            <button className="text-gray-400 hover:text-white transition">
              <Shuffle size={20} />
            </button>
            <button className="text-gray-400 hover:text-white transition">
              <SkipBack size={20} />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-white text-black hover:scale-105 transition"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-0.5" />}
            </button>
            <button className="text-gray-400 hover:text-white transition">
              <SkipForward size={20} />
            </button>
            <button className="text-gray-400 hover:text-white transition">
              <Repeat size={20} />
            </button>
          </div>
          <div className="w-full flex items-center gap-2 text-xs text-gray-400">
            <span>2:14</span>
            <div className="flex-1 h-1 bg-gray-600 rounded-full">
              <div className="w-1/3 h-full bg-gray-200 rounded-full hover:bg-green-500" />
            </div>
            <span>{currentTrack.duration}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 w-1/4 justify-end">
          <Volume2 size={20} className="text-gray-400" />
          <input
            type="range"
            min="0"
            max="100"
            value={volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            className="w-24"
          />
        </div>
      </div>
    </div>
  );
}