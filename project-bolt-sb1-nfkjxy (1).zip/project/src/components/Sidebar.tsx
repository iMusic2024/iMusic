import React from 'react';
import { Home, Search, Library, Plus, Heart } from 'lucide-react';

export default function Sidebar() {
  return (
    <div className="w-64 bg-black h-full flex flex-col p-6">
      <div className="flex items-center gap-2 mb-8">
        <div className="w-8 h-8">
          <svg viewBox="0 0 24 24" className="w-full h-full text-green-500">
            <path
              fill="currentColor"
              d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.371-.721.531-1.152.371-3.161-1.931-7.141-2.371-11.842-1.301-.458.101-.902-.201-1.003-.658-.101-.458.201-.902.658-1.003 5.141-1.181 9.601-.67 13.162 1.541.431.271.572.812.271 1.152zm1.472-3.341c-.302.453-.842.653-1.293.402-3.622-2.226-9.144-2.873-13.416-1.573-.552.169-1.134-.143-1.302-.694-.169-.552.143-1.134.694-1.302 4.922-1.5 11.024-.769 15.196 1.874.452.301.652.842.402 1.293zm.126-3.472c-4.341-2.576-11.504-2.816-15.645-1.558-.661.205-1.362-.162-1.567-.823-.205-.661.162-1.362.823-1.567 4.771-1.449 12.704-1.169 17.725 1.798.524.309.696.984.387 1.508-.31.524-.985.696-1.509.387z"
            />
          </svg>
        </div>
        <span className="text-xl font-bold">Spotify</span>
      </div>

      <nav className="space-y-6">
        <a href="#" className="flex items-center gap-4 text-gray-300 hover:text-white transition">
          <Home size={24} />
          <span className="font-medium">Home</span>
        </a>
        <a href="#" className="flex items-center gap-4 text-gray-300 hover:text-white transition">
          <Search size={24} />
          <span className="font-medium">Search</span>
        </a>
        <a href="#" className="flex items-center gap-4 text-gray-300 hover:text-white transition">
          <Library size={24} />
          <span className="font-medium">Your Library</span>
        </a>
      </nav>

      <div className="mt-8 space-y-4">
        <button className="flex items-center gap-4 text-gray-300 hover:text-white transition">
          <div className="w-6 h-6 bg-gray-300 hover:bg-white transition flex items-center justify-center rounded-sm">
            <Plus size={16} className="text-black" />
          </div>
          <span className="font-medium">Create Playlist</span>
        </button>
        <button className="flex items-center gap-4 text-gray-300 hover:text-white transition">
          <div className="w-6 h-6 bg-gradient-to-br from-purple-700 to-gray-300 flex items-center justify-center rounded-sm">
            <Heart size={16} className="text-white" />
          </div>
          <span className="font-medium">Liked Songs</span>
        </button>
      </div>

      <div className="mt-6 pt-6 border-t border-gray-800">
        <div className="space-y-2">
          {['Chill Mix', 'Dance Vibes', 'Rock Classics'].map((playlist) => (
            <a
              key={playlist}
              href="#"
              className="block text-sm text-gray-300 hover:text-white transition"
            >
              {playlist}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}