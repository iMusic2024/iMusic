import React from 'react';
import Sidebar from './components/Sidebar';
import Player from './components/Player';
import MainContent from './components/MainContent';

function App() {
  return (
    <div className="h-screen bg-black text-white flex">
      <Sidebar />
      <main className="flex-1 overflow-auto pb-24 bg-gradient-to-b from-gray-900 to-black">
        <MainContent />
      </main>
      <Player />
    </div>
  );
}

export default App;