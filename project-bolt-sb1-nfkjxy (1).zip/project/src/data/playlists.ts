export const playlists = [
  {
    id: '1',
    title: 'Discover Weekly',
    description: 'Your weekly mixtape of fresh music',
    cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300',
    tracks: [
      {
        id: '1',
        title: 'Starlight',
        artist: 'The Midnight',
        album: 'Monsters',
        duration: '4:56',
        cover: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=300'
      },
      {
        id: '2',
        title: 'Neon Dreams',
        artist: 'FM-84',
        album: 'Atlas',
        duration: '5:12',
        cover: 'https://images.unsplash.com/photo-1614613534052-8c1d14249c50?w=300'
      }
    ]
  },
  {
    id: '2',
    title: 'Chill Vibes',
    description: 'Relaxing beats for your day',
    cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300',
    tracks: [
      {
        id: '3',
        title: 'Midnight City',
        artist: 'Waveshaper',
        album: 'Station Nova',
        duration: '4:23',
        cover: 'https://images.unsplash.com/photo-1614613533542-ec22d5f15b46?w=300'
      }
    ]
  }
];