export const FEATURED_PLAYLISTS = [
  {
    id: "1",
    title: "Today's Hits",
    image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop",
    songs: [
      {
        id: "1",
        title: "Never Gonna Give You Up",
        artist: "Rick Astley",
        videoId: "dQw4w9WgXcQ",
        thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop"
      },
      {
        id: "2",
        title: "Bring Me To Life",
        artist: "Evanescence",
        videoId: "3YxaaGgTQYM",
        thumbnail: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop"
      },
      {
        id: "3",
        title: "Bohemian Rhapsody",
        artist: "Queen",
        videoId: "fJ9rUzIMcZQ",
        thumbnail: "https://images.unsplash.com/photo-1511735111819-9a3f7709049c?w=300&h=300&fit=crop"
      }
    ]
  },
  {
    id: "2",
    title: "Chill Vibes",
    image: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=300&h=300&fit=crop",
    songs: [
      {
        id: "4",
        title: "The Scientist",
        artist: "Coldplay",
        videoId: "RB-RcX5DS5A",
        thumbnail: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop"
      },
      {
        id: "5",
        title: "Say You Won't Let Go",
        artist: "James Arthur",
        videoId: "0yW7w8F2TVA",
        thumbnail: "https://images.unsplash.com/photo-1471565661762-b9dfae862dbe?w=300&h=300&fit=crop"
      }
    ]
  }
];